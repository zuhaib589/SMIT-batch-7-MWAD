export default function Blog(){
    return(
        <div>
            <h1>Blog Details</h1>
        </div>
    )
}