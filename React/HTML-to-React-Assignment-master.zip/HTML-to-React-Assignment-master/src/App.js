import './style.css'
import Nav from './navigation/Navigation'
export default function App() {
  return (
    <div>
      <Nav/>
    </div>
  )
}
