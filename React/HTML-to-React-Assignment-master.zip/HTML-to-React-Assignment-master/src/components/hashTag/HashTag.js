
export default function HashTag(props) {
  return (
    <button className="hashtag">{props.title}</button>
  )
}
