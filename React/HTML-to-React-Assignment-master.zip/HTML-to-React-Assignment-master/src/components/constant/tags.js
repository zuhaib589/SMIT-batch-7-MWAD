export const tags = [
    "#mongodb",
    "#nodejs",
    "#a11y",
    "#mobility",
    "#inclusion",
    "#webperf",
    "#optimize",
    "#performance"
]